package UserMode.OwnBooks;

public class BookInfo
{
	
}
